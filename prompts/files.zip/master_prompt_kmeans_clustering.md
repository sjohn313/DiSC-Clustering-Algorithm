# Master Prompt: K-Means Clustering – Career SCM Dataset

## Your Role
You are an expert AI/ML engineer specializing in unsupervised machine learning in R. When given this prompt, your sole task is to write a complete, executable R script that performs K-Means clustering on an existing dataset and exports all outputs. Do not explain the code — just write it.

---

## Task
Write an R script that:
1. Loads `C:/Users/sebas/dev/data_creation_project(for clustering)/output/career_scm_data.csv` (generated from a prior Structural Causal Model)
2. Preprocesses the data for clustering
3. Runs K-Means with **100 random initializations** (`nstart = 100`) across a range of k values
4. Uses **both the Elbow Method and Silhouette Score** to determine the optimal number of clusters
5. Fits the final K-Means model using the best k
6. Exports all required outputs

---

## Input Data
- **File:** `C:/Users/sebas/dev/data_creation_project(for clustering)/output/career_scm_data.csv`
- **Variables present:**
  - `age` (numeric)
  - `career_length_years` (numeric)
  - `hierarchy_status` (integer: 1, 2, 3)
  - `industry` (categorical string)
  - `starting_salary` (numeric)
  - `current_salary` (numeric)
  - `disc_style` (categorical string: D, I, S, C)

---

## Preprocessing Requirements
- **Scale all numeric variables** using `scale()` before clustering (z-score normalization)
- **Encode categorical variables** numerically before clustering:
  - `industry`: convert to dummy variables or integer encode
  - `disc_style`: convert to integer encode (D=1, I=2, S=3, C=4)
  - `hierarchy_status`: already integer, include as-is after scaling
- Drop any rows with NA values before clustering
- Keep the original unscaled dataframe intact for output and summary purposes

---

## K-Means Configuration
- **Initializations:** `nstart = 100` (100 random starts per k to minimize local minima)
- **Algorithm:** `algorithm = "Hartigan-Wong"` (most robust)
- **K range to evaluate:** k = 2 through k = 10
- **Max iterations:** `iter.max = 300`
- **Random seed:** `set.seed(42)` at the top of the script

---

## Optimal K Selection — Two Methods

### Method 1: Elbow Method (WCSS)
- For each k from 2–10, record the **Within-Cluster Sum of Squares (WCSS)** from `kmeans()$tot.withinss`
- Plot WCSS vs. k as a line chart with points
- Identify the "elbow point" programmatically using the **maximum second derivative** (rate of change of WCSS drop)
- Label the elbow point on the plot
- Save plot as `C:/Users/sebas/dev/data_creation_project(for clustering)/output/elbow_plot.png`

### Method 2: Silhouette Score
- For each k from 2–10, compute the **average silhouette width** using the `cluster` package (`silhouette()` function)
- Plot average silhouette score vs. k as a line chart with points
- Optimal k = k with the **highest average silhouette score**
- Label the optimal point on the plot
- Save plot as `C:/Users/sebas/dev/data_creation_project(for clustering)/output/silhouette_plot.png`

### Final K Decision
- Compare the elbow k and silhouette k
- If they agree → use that k
- If they disagree → **default to the silhouette k** (more statistically rigorous) and print a message to the console noting the disagreement and the final choice
- Store final k as `best_k`

---

## Final Model
- Refit K-Means using `best_k`, `nstart = 100`, `iter.max = 300`, `set.seed(42)`
- Add cluster assignments back to the **original unscaled dataframe** as a new column: `cluster` (integer)

---

## Required Outputs

### 1. Elbow Plot
- File: `C:/Users/sebas/dev/data_creation_project(for clustering)/output/elbow_plot.png`
- X-axis: Number of Clusters (k)
- Y-axis: WCSS (Total Within-Cluster Sum of Squares)
- Title: "Elbow Method – Optimal K Selection"
- Elbow point highlighted and labeled

### 2. Silhouette Plot
- File: `C:/Users/sebas/dev/data_creation_project(for clustering)/output/silhouette_plot.png`
- X-axis: Number of Clusters (k)
- Y-axis: Average Silhouette Width
- Title: "Silhouette Score – Optimal K Selection"
- Best k highlighted and labeled

### 3. WCSS / Inertia Error Table
- A dataframe with columns: `k`, `wcss`, `silhouette_score`
- Print to console
- Export as `C:/Users/sebas/dev/data_creation_project(for clustering)/output/kmeans_error_table.csv`

### 4. Cluster Summary Statistics
- For each cluster, compute the **mean of all numeric variables** grouped by cluster assignment
- Include cluster size (n per cluster)
- Print to console
- Export as `C:/Users/sebas/dev/data_creation_project(for clustering)/output/cluster_summary.csv`

### 5. Clustered Dataset
- The original `C:/Users/sebas/dev/data_creation_project(for clustering)/output/career_scm_data.csv` with a new `cluster` column appended
- Export as `C:/Users/sebas/dev/data_creation_project(for clustering)/output/career_scm_clustered.csv`

---

## R Package Requirements
Use the following packages (include `library()` calls at the top):
- `cluster` — for silhouette scoring
- `ggplot2` — for plots
- `dplyr` — for data manipulation
- `readr` — for CSV import/export

---

## Console Output Requirements
Print the following to the console during execution:
- Confirmation that data loaded successfully (n rows, n columns)
- WCSS and silhouette score for each k as it is evaluated
- The elbow k and silhouette k found
- The final chosen `best_k` and the reason (agreement or silhouette default)
- Confirmation of each file exported

---

## Output
A single, complete, copy-paste-ready R script. Nothing else.
