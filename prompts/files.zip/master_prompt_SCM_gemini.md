# Master Prompt: Structural Causal Model – Career & Salary Dataset

## Your Role
You are an expert R programmer specializing in Structural Causal Models (SCMs). When given this prompt, your sole task is to write a complete, executable R script that generates a realistic synthetic dataset and exports it as a CSV file. Do not explain the code — just write it.

---

## Task
Write an R script that builds a Structural Causal Model (SCM) to generate **1,000 rows** of synthetic career and salary data. The script must export the final dataset as a CSV file named `C:/Users/sebas/dev/data_creation_project(for clustering)/output/career_scm_data.csv`.

---

## Variables to Generate

| Variable | Type | Description |
|---|---|---|
| `age` | Numeric (integer) | Age of individual, range 22–65 |
| `career_length_years` | Numeric (continuous) | Total years in current career; causally derived from age (career_length = age - 22 + small noise, capped realistically) |
| `hierarchy_status` | Categorical (ordered integer) | 1 = Entry Level, 2 = Mid Level, 3 = Executive; causally driven by career_length — longer tenure increases probability of higher hierarchy |
| `industry` | Categorical (string) | One of: "Healthcare", "Technology", "Finance", "Education" — assigned with realistic proportions |
| `starting_salary` | Numeric (continuous) | Starting salary at career entry; varies by industry (Technology and Finance higher, Education lower) with added noise |
| `current_salary` | Numeric (continuous) | Current salary; causally driven by starting_salary, career_length_years, and hierarchy_status — executives earn significantly more, longer careers yield higher salaries |
| `disc_style` | Categorical (string) | Dominant DiSC style: one of "D", "I", "S", "C"; assigned with roughly equal proportions (may vary slightly by hierarchy — e.g., D more common in Executive) |

---

## Causal Structure (DAG)
The SCM must reflect this causal hierarchy:

```
age → career_length_years → hierarchy_status → current_salary
                                   ↑                   ↑
                               industry          starting_salary
                                                       ↑
                                                   industry
disc_style → (minor influence on hierarchy_status, e.g., D types slightly more likely to be executive)
```

---

## Realism Requirements
- **Age** should be drawn from a realistic working-age distribution (skew slightly toward 30–50).
- **Career length** must be logically consistent with age (a 25-year-old cannot have 20 years of experience).
- **Hierarchy status** probabilities must increase with career length:
  - 0–5 years → mostly Entry Level
  - 6–15 years → mostly Mid Level
  - 16+ years → mostly Executive
- **Industry salary baselines** (approximate annual starting salary):
  - Technology: $75,000–$95,000
  - Finance: $65,000–$85,000
  - Healthcare: $55,000–$75,000
  - Education: $38,000–$52,000
- **Current salary** must always be ≥ starting salary. Apply a realistic growth multiplier based on career length and hierarchy level.
- **No impossible values**: no negative salaries, no career lengths longer than (age - 18), no one under 22.
- Add normally distributed noise to all continuous variables to avoid perfect correlations.

---

## R Script Requirements
- Use base R only (no external packages required), OR use `tidyverse` and `MASS` if needed — specify with `library()` calls at the top.
- Set a random seed at the top: `set.seed(42)`
- Name the final dataframe `career_data`
- Export with: `write.csv(career_data, "C:/Users/sebas/dev/data_creation_project(for clustering)/output/career_scm_data.csv", row.names = FALSE)`
- Include brief inline comments explaining each causal step.

---

## Output
A single, complete, copy-paste-ready R script. Nothing else.
